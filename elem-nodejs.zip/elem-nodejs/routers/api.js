var express = require('express');
var router = express.Router();

var user = require('./api/user.js');
var shop = require('./api/shop.js');
var order = require('./api/order.js');
//router.get('/',function (req,res) {
//    res.send('api')
//});
router.use('/user',user);                    //用户接口
router.use('/shop',shop);                    //商家接口
router.use('/order',order);                  //商品订单接口

module.exports = router;