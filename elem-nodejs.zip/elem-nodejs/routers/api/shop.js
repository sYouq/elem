/**
 * Created by Administrator on 2017/11/21 0021.
 */
var express = require('express');
var router = express.Router();
var bodyparser=require('body-parser');
router.use(bodyparser.urlencoded({extended:false}));
router.use(bodyparser.json());
var DB=require('../../modules/db.js');

//http://localhost:8001/api/shop?page=1
router.get('/',function (req,res) {
    var page=req.query.page || 1;
    var pageSize=10;
    var keyword=req.query.keyword;  /*获取get传值*/
    //console.log(req.query);
    var json=keyword?{"name":{$regex:new RegExp(keyword)}}:{};
    DB.find('shop',json,{},{
        page,
        pageSize
    },function(err,data){
        res.jsonp({
            "result":data,
            "page":page
        })
    })
});
//http://localhost:8001/api/shop/id
router.post('/id',function (req,res) {
    var id=req.body.id;
    DB.find('shop',{"_id":new DB.ObjectId(id)},function(err,data){
        if(data==''){
            res.jsonp({
                "result":id+"id错误"
            })
        }else{
            res.jsonp({
                "result":data[0]
            })
        }
    })
});

module.exports = router;