/**
 * Created by Administrator on 2017/11/21 0021.
 */
var express = require('express');
var router = express.Router();
var md5=require('md5');
var bodyparser=require('body-parser');
router.use(bodyparser.urlencoded({extended:false}));
router.use(bodyparser.json());
var DB=require('../../modules/db.js');
var dateTime=require('date-time');
var session = require('express-session');
router.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: true }
}))

//用户数据的接口  http://localhost:8001/api/user/
router.get('/',function (req,res) {
    DB.find('user',{},function(err,data){
        res.jsonp({
            "result":data,
        })
    });
});

//提交手机号短信的接口  http://localhost:8001/api/user/tel
router.post('/tel',function (req,res) {
    //生成随机验证码
    function yzm(){
        var str='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        var yzm='';
        for(var i=0;i<6;i++){
            var randomNum=Math.floor(Math.random()*str.length);
            yzm+=str[randomNum];
        }
        return yzm;
    }
    //console.log(req.body);
    var tel=req.body.tel;
    //console.log(tel);
    //查找数据user表中有没有这个电话号码
    DB.find('user',{"tel":tel},function(err,data){
        //console.log(data)
        if(!err){
            //如果没有
            if(data==''){
                //查找这个电话号码有没有获取过验证码
                DB.find('yzm',{"tel":tel},function(err,data){
                    //如果没有给前端返回生成的随机验证码
                    if(data==''){
                        var oyzm=yzm();
                        DB.insert('yzm',{"tel":tel,"yzm":oyzm,"add_time":Date.parse(new Date())},function(err,data){
                            if(!err){
                                //console.log(data);
                                res.jsonp({
                                    "result":oyzm
                                });
                            }
                        })
                    }else{
                    //如果有，修改yzm表中的验证码
                        var oyzm=yzm();
                        DB.update('yzm',{"tel":tel},{"yzm":oyzm,"add_time":Date.parse(new Date())},function(err,data){
                            if(!err){
                                //console.log(data);
                                res.jsonp({
                                    "result":oyzm
                                });
                            }
                        })
                    }
                })
                //req.session.oyzm=oyzm;
            }else{
                //如果user表中存在这个电话号码，给前端返回用户已存在信息
                res.jsonp({
                    "result":'用户已存在'
                });
            }
            return;
        }
        res.jsonp({
            "result":'提交错误'
        });
    });
});
//判断验证码    http://localhost:8001/api/user/yz
router.post('/yz',function(req,res){
    //获取前台提交的验证码电话号码
    //console.log(req.body);
    var tel=req.body.tel;
    var yzm=req.body.yzm;
    var now=parseFloat(Date.parse(new Date()));         //生成一个当前时间的时间戳
    //以电话为准查找表中对应的验证码进行对比
    DB.find('yzm',{"tel":tel},function(err,data){
        var old=parseFloat(data[0].add_time);//强制转换
        //验证码在十五分钟之内有效
        //console.log(data);
        if(now-old<=900000){
            //如果验证码验证正确，给前端返回验证成功进行下一步
            if(yzm==data[0].yzm){
                res.jsonp({
                    result:true,
                    msg:'验证成功'
                });
            }else{
                res.jsonp({
                    result:false,
                    msg:'验证码错误'
                });
            }
        }else{
            //超过15分钟，返回验证码过期
            res.jsonp({
                result:false,
                msg:'验证码过期，请重新获取'
            });
        }
    })
})
//注册   http://localhost:8001/api/user/register
router.post('/register',function (req,res) {
    //获取前台提交的数据  保存到数据库
    //console.log(req.body);
    var username=req.body.username;
    var tel=req.body.tel;
    var add_time=dateTime({date:new Date()});
    var password=md5(req.body.password);
    DB.insert('user',{username,tel,add_time,password,status:0},function(err,data){
        if(!err){
            res.jsonp({
                result:true,
                msg:'注册成功'
            });
            return;
        }
        res.jsonp({
            result:false,
            msg:'注册失败'
        });
    })
});
//登录   http://localhost:8001/api/user/login
router.post('/login',function (req,res) {
    //console.log(req.body);
    var tel=req.body.tel;
    //console.log(tel);
    var password=md5(req.body.password);
    DB.find('user',{"tel":tel,"password":password},function(err,data){
        if(!err){
            if(data.length>0){
                res.jsonp({
                    "msg":"登录成功",
                    "status":true,
                    "result":data[0]
                });

            }else {
                res.jsonp({
                    "status":false,
                    "msg":'登录失败'
                });

            }
            return;
        }
        res.jsonp({
            "status":false,
            "msg":'登录失败'
        });
    })
});

//暂时不用   验证码的接口:    http://localhost:8001/api/user/yzm
router.get('/yzm',function (req,res) {
    function yzm(){
        var str='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        var yzm='';
        for(var i=0;i<6;i++){
            var randomNum=Math.floor(Math.random()*str.length);
            yzm+=str[randomNum];
        }
        return yzm;
    }
    res.jsonp({
        "result":yzm()
    });
    //res.send(yzm());
});

module.exports = router;
