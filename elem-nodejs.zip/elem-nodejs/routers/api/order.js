/**
 * Created by Administrator on 2017/11/21 0021.
 */
var express = require('express');
var router = express.Router();
var bodyparser=require('body-parser');
router.use(bodyparser.urlencoded({extended:false}));
router.use(bodyparser.json());
var DB=require('../../modules/db.js');
//订单详情接口   http://localhost:8001/api/order/
router.get('/',function (req,res) {
    //res.send('订单')
    DB.find('order',{},function(err,data){
        res.jsonp({
            "result":data,
        })
    });
});
//订单提交接口   http://localhost:8001/api/order/
router.post('/',function (req,res) {
    //res.send('订单')
    //console.log(req.body);
    var order_id=req.body.order_id;
    var shop_name=req.body.shop_name;
    var shop_id=req.body.shop_id;
    var shop_tel=req.body.shop_tel;
    var uid=req.body.uid;
    var username=req.body.username;
    var user_tel=req.body.user_tel;
    DB.insert('order',{order_id,shop_name,shop_id,shop_tel,uid,username,user_tel,order_status:0},function(err,data){
        if(!err){
            res.jsonp('提交订单成功');
            return;
        }
        res.jsonp('提交订单失败');
    });
});
//根据uid获取订单的接口  http://localhost:8001/api/order/uid?page=1
router.post('/uid',function (req,res) {
    //res.send('订单')
    var page=req.query.page || 1;
    var pageSize=10;
    //console.log(req.body);
    var uid=req.body.uid;
    DB.find('order',{"uid":uid},{},{
        page,
        pageSize
    },function(err,data){
       if(!err){
           if(data==''){
               res.jsonp({
                   "result":"没有找到订单"
               });
           }else{
               res.jsonp({
                   "result":data,
                   "page":page
               })
           }
           return;
       }
        res.jsonp("获取失败");
    });
});
module.exports = router;