var express = require('express');
var router = express.Router();

var index = require('./admin/index.js');
var login = require('./admin/login.js');
var admin = require('./admin/admin.js');
var user = require('./admin/user.js');
var shop = require('./admin/shop.js');
var order = require('./admin/order.js');

// 登录判断权限
router.use(function (req,res,next) {
    req.app.locals.username = 'zhanfsan';  //设置全局ejs模板内容
    if(req.session.userinfo && req.session.userinfo.username != ''){
        // req.app.locals.username = req.session.userinfo.username;  //设置全局ejs模板内容
        next();
    }else{
        if(req.url == '/login' || req.url == '/login/toLogin'){
            next();
        }else{
            // res.redirect('/admin/login');
            next();
        }
    }
})

//后台路由
router.use('/',index);                        //后台首页
router.use('/login',login);                  //管理员登录
router.use('/admin',admin);                  //管理员管理
router.use('/user',user);                    //管理员管理
router.use('/shop',shop);                    //商家管理
router.use('/order',order);                  //商品订单管理

module.exports = router;

