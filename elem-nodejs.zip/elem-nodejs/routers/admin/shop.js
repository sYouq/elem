var express = require('express');
var router = express.Router();
var DB = require("../../modules/db.js");
var multiparty = require('multiparty');
var async=require('async');
var fs = require('fs');

router.get('/',function (req,res) {
    var keyword=req.query.keyword;  /*获取get传值*/
    var json=keyword?{"name":{$regex:new RegExp(keyword)}}:{};
    var page=req.query.page || 1;
    var pageSize=8;
    async.parallel({
        count: function (callback) {
            DB.count('shop',json,function(err,countNum){
                callback(err,countNum);
            })
        },
        list: function (callback) {
            DB.find('shop',json,{},{
                page:page,
                pageSize:pageSize
            },function(err,data){
                callback(err,data)
            })
        },
    }, function(err, results){
        res.render('admin/shop/index',{
            list:results.list,
            keyword:keyword,
            page:page,
            totalPage:Math.ceil(results.count/pageSize)
        })
    })
});

//增加
router.get('/add',function (req,res) {
   res.render('admin/shop/add')
});

router.post('/doAdd',function (req,res) {
    var form = new multiparty.Form();
    form.uploadDir='public/admin/upload';  /*上传图片的路径    注意：路径相对于根目录 */
    form.parse(req, function(err, fields, files) {
        //console.log(fields);
        //console.log(files);
        var name=fields.name[0];
        var pic=files.pic[0].path;
        var description=fields.description[0];
        var status=fields.status[0];
        var address=fields.address[0];
        var tel=fields.tel[0];
        DB.insert("shop",{
            name,pic,description,address,status,tel
        }, function (err, result) {
            if(!err){
                res.redirect('/admin/shop');
            }
        })
    })
});

//修改
router.get('/edit',function (req,res) {
    var id=req.query.id;
    DB.find('shop',{"_id":new DB.ObjectId(id)},function(err,data){  /*列表*/
        res.render('admin/shop/edit',{
            list:data[0]
        });
    })
});
router.post('/doEdit',function (req,res) {
    //接收表单的数据  注意enctype="multipart/form-data"
    var form = new multiparty.Form();
    form.uploadDir='public/admin/upload';  /*上传图片的路径    注意：路径相对于根目录 */
    form.parse(req, function(err, fields, files) {
        //console.log(fields);
        //console.log(files);
        var id=fields.id[0];
        var name=fields.name[0];
        var pic=files.pic[0].path;
        var description=fields.description[0];
        var status=fields.status[0];
        var address=fields.address[0];
        var tel=fields.tel[0];
        //根据cid获取分类
        //DB.find('product_cate',{"_id":new DB.ObjectId(cate_id)},function(err,data){  /*获取选择的分类*/
        //    var cate_name=data[0].title;
        //判断有没有修改图片
        var originalFilename=files.pic[0].originalFilename;
        if(originalFilename){
            var json ={
                name,pic,description,address,status,tel
            };
        }else{
            var json ={
                 name,description,address,status,tel
            };
            //删除插件生成的错误的图片
            fs.unlink(pic);
        }
        DB.update("shop",{'_id':new DB.ObjectId(id)},json, function (err, result) {
            if(!err){
                res.redirect('/admin/shop');
            }
        })
        //})
    })
});

//删除
router.get('/delete',function (req,res) {
    var id=req.query.id;
    //console.log(id)
    DB.delete('shop',{"_id":new DB.ObjectId(id)},function(err,data){  /*列表*/
        if(!err){
            res.redirect('/admin/shop');
        }
    })
});



module.exports = router;