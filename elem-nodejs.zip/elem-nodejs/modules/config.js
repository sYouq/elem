var dbURL = 'mongodb://10.36.135.129:27017/projects';

module.exports = {
    dbURL : dbURL
};