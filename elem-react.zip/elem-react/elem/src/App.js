import React, { Component } from 'react';
import Index from './components/Index.js';
import My from './components/My.js';
import Faind from './components/Faind.js';
import Indent from './components/Indent.js';
import Login from './components/Login.js';
import Login01 from './components/Login01.js';
import Login02 from './components/Login02.js';
import Order from './components/Order.js';
import AddSite from './components/AddSite.js';
import Detials from './components/Detials.js';
import Search from './components/Search.js';
import Sever from './components/Sever.js';
import Store from './components/Store.js';
import Add from './components/Add.js';
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom';
class App extends Component {
  render() {
    return (
      <Router>
      <div>
      <Route exact path="/" component={Index}/>
      <Route path="/index" component={Index}/>
        <Route path="/faind" component={Faind}/>
        <Route path="/indent" component={Indent}/>
        <Route path="/my" component={My}/>
        <Route path="/login" component={Login}/>
        <Route path="/login01" component={Login01}/>
        <Route path="/login02" component={Login02}/>
        <Route path="/order" component={Order}/>
        <Route path="/addsite" component={AddSite}/>
        <Route path="/detials/:aid" component={Detials}/>
        <Route path="/search" component={Search}/>
        <Route path="/sever" component={Sever}/>
        <Route path="/store" component={Store}/>
        <Route path="/add" component={Add}/>
      </div>
      </Router>
    )
  }
}

export default App;
