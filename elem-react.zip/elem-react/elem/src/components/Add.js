import React from 'react';

import '../css/Reset.css';
import '../css/add.css';
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom';

class Add extends React.Component{


    constructor(props){
        super(props);

        this.state={
 
            
        }
    }

    render(){

        return(
            <div id="add">
            <div className="head">
			<i className="iconfont">&#xe648;</i>
			<span>收货地址</span>
		</div>
		<div className="box">
			<div className="nav">
				<div className="left">
					<p><i>学校</i>地址地址地址李长猛的家adsf asdffasd fas 里地址</p>
					<span>李长猛</span>
					<span>13144444444</span>
				</div>
				<i className="iconfont">&#xe66c;</i>
			</div>
		</div>
		<div className="bast">
			<a><i>+</i><span>新增收货地址</span></a>
		</div>
            </div>
        )
    }
}

export default Add;
