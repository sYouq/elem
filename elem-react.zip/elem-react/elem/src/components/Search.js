import React from 'react';
import '../css/Reset.css';
import '../css/search.css';
import {
	BrowserRouter as Router,
	Route,
	Link,
	withRouter
  } from 'react-router-dom';
import axios from 'axios';

class Search extends React.Component{


    constructor(props){
        super(props);

        this.state={
            keyword:'',
            page:1,
            list:[]
            
        }
        this.goBack=this.goBack.bind(this);
        this.shopChange=this.shopChange.bind(this);
        this.search=this.search.bind(this);
    }


    render(){

        return(	
        <div id="search">
            <div id="header4">
            <div className="arrow">
                <i className="iconfont" onClick={this.goBack}>&#xe609;</i>
            </div>
            <div className="search-box">
                
                <div className="search">
                    <input type="text" placeholder="搜索商家、商品名称" value={this.state.keyword} onChange={this.shopChange}/>
                    <i className="iconfont">&#xe960;</i>
                </div>
            </div>
            <div className="search-words">
                <span onClick={this.search}>搜索</span>
            </div>
        </div>
        <div className="main">
        <div className="box1">
        <div className="main-top">
                <span>搜索结果</span>
        </div>
        <div className="history-search">
        {
            this.state.list.map(function(item,key){
                return <span className="sp" key={key}>
                {item.name}
            </span>
            })
        }
        </div>
    </div>
        
            <div className="box1">
                <div className="main-top">
                        <span>历史搜索</span>
                        <i className="iconfont">&#xe603;</i>
                </div>
                <div className="history-search">
                    <span className="sp">
                        长猛焖鸡
                    </span>
                    <span className="sp">
                        长猛河粉
                    </span>
                    <span className="sp">
                        长猛鱼粉
                    </span>
                    <span className="sp">
                        长猛蛋炒饭
                    </span>
                </div>
            </div>
            <div className="box1">
                    <div className="main-top">
                        <span>热门搜索</span>
                    </div>
                    <div className="history-search">
                        <span className="sp">
                            长猛华莱士
                        </span>
                        <span className="sp">
                            周黑猛
                        </span>
                        <span className="sp">
                            猛拉面
                        </span>
                        <span className="sp">
                            花生猛
                        </span>
                    </div>
                </div>
        </div>
    </div>
        
        )
    }
    goBack(){
        this.props.history.push('/');
    }
    shopChange(event){
        this.setState({keyword: event.target.value});
    }
    search(){
        var url='http://localhost:8001/api/shop?keyword='+this.state.keyword;
		axios.get(url)
		.then((response)=> {
		  console.log(response.data.result);
		if(response.data.result.length>0){
            this.setState({        
                list:response.data.result,
                page:++this.state.page
            })  
        }
	}).catch(function(err){
		console.log(err);        
	})
    }
}

export default Search;
