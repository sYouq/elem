import React from 'react';

import '../css/AddSite.css';
import '../css/Reset.css';
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom';

class AddSite extends React.Component{


    constructor(props){
        super(props);

        this.state={
 
            
        }
    }

    render(){

        return(
            <div>
            <div id="header2">
			<a href="#" className="iconfont">&#xe648;</a>
			<span>新增地址</span>
		</div>
		<div id="main1">
			<form>
				<div className="lxr">
					<span>联系人</span>
					<div className="m-right">
						<input type="text" placeholder="姓名" />
						<p><a href="#">先生</a><a href="#">女士</a>	</p>
					</div>
				</div>
				
				<div className="tel">
					<span>电话</span>
					<div className="m-right">
						<input type="text" placeholder="收货人电话" />
						<a href="#">+通讯录</a>
					</div>
				</div>
				
				<div className="address">
					<span>地址</span>
					<div className="m-right">
						<p><input type="text" placeholder="小区/写字楼/学校等" /><a href="#" className="iconfont">&#xe608;</a></p>
						<p><input type="text" placeholder="详细地址" className="dt-ress" /></p>
					</div>
				</div>
				
				<div className="tablet">
					<span>门牌号</span>
					<input type="text" placeholder="例：5号楼203室" />
				</div>
							
				<div className="latel">
					<span>标签</span>
					<div className="m-right">
						<a href="#">家</a><a href="#">公司</a><a href="#">学校</a>
					</div>
				</div>
				
				<input type="submit" name="" className="sub" />
			</form>
		</div>
            </div>
        )
    }
}

export default AddSite;
