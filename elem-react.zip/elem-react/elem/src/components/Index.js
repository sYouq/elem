import React from 'react';
import '../css/Reset.css';
import '../css/Index.css';
import '../css/Head.css';
import Footer from './Footer.js';
 import pic1 from '../img/199d358d7d5757ab2f6184b153cc4jpeg.jpeg';
 import pic2 from '../img/45b2ec2855ed55d90c45bf9b07abbpng.png';
 import axios from 'axios';
 import InfiniteScroll from 'react-infinite-scroller';
 import {
	BrowserRouter as Router,
	Route,
	Link,
	withRouter
  } from 'react-router-dom';
class Index extends React.Component{


    constructor(props){
        super(props);

        this.state={

			msg:'首页',
			page:1,
			list:[],
			hasMore:true,
			address:"无"
		}
		this.getShop=this.getShop.bind(this);
		this.loadFunc=this.loadFunc.bind(this);
		this.goSearch=this.goSearch.bind(this);
    }

    render(){
		var items=this.state.list.map((item,key)=>{
			return <div className="tuij-content" key={key}>
			<Link to={`/detials/${item._id}`}>
			<div className="shop">
				<div className="shop-top">
					<div className="s-left">
					<img src={"http://localhost:8001/" + item.pic}/>
			
					</div>
					<div className="s-right">
						<div className="title">
							<h4>{item.name}</h4>
							<small>票</small>
						</div>
						<div className="pinj">
							<span className="xing"><i className="iconfont">&#xe68b;</i><i className="iconfont">&#xe68b;</i><i className="iconfont">&#xe68b;</i><i className="iconfont">&#xe68b;</i><i className="iconfont">&#xe68b;</i></span>
							<small>4.5</small>
							<span className="yue">月售77单</span>
						</div>
						<div className="qisong">
							<span>￥30起送 | 配送费￥4 ￥52/人</span>
							<small>690m</small>
						</div>
					</div>
				</div>
			</div>
			<div className="shop-bottom">
				<div className="b-content">
					<div className="b-left">
						<span><small>首</small>新用户下单立减17元</span>
						<span><small>减</small>满40减12，满60减20</span>
					</div>
				</div>
			</div>
			</Link>
		</div>
		
		}) 
        return(
            <div>
           <div className="map">
			<div className="map-content">
				<i className="iconfont">&#xe627;</i>
				<span>{this.state.address}</span>
			</div>
		</div>
		
		<div className="head">
			
			 	<input type="text" placeholder="搜索商家/商品名称" className="txt" onClick={this.goSearch}/>
			 	<i className="iconfont search">&#xe960;</i>
		
		</div>
		
		<div className="icon">
			<ul>
				<li><a href="#"> <img src={pic1}/><span>美食</span></a></li>
				<li><a href="#"> <img src={pic1}/><span>甜点甜品</span></a></li>
				<li><a href="#"> <img src={pic1}/><span>商超便利</span></a></li>
				<li><a href="#"> <img src={pic1}/><span>果蔬生鲜</span></a></li>
				<li><a href="#"> <img src={pic1}/><span>新店特惠</span></a></li>
				<li><a href="#"> <img src={pic1}/><span>准时达</span></a></li>
				<li><a href="#"> <img src={pic1}/><span>简餐</span></a></li>
				<li><a href="#"> <img src={pic1}/><span>汉堡薯条</span></a></li>
			</ul>
		</div>
		
		
		<div className="welfare">
			<img src={pic2}/>
		</div>
		
		
		<div className="kong"></div>
		
		
		<div className="activity">
			<ul>
				<li>
					<a href="#">
						<strong>
							满20减10
							<span>广深大聚会</span>
						</strong>
						<img src={pic1}/>
					</a>
				</li>
				<li>
					<a href="#">
						<strong>
							满20减10
							<span>广深大聚会</span>
						</strong>
						<img src={pic1}/>
					</a>
				</li>
				<li>
					<a href="#">
						<strong>
							满20减10
							<span>广深大聚会</span>
						</strong>
						<img src={pic1}/>
					</a>
				</li>
				<li>
					<a href="#">
						<strong>
							满20减10
							<span>广深大聚会</span>
						</strong>
						<img src={pic1}/>
						</a>
				</li>
				
			</ul>
		</div>
		
		
		<div className="kong"></div>
		
		
		<div className="tuij">		
			<h3>推荐商家</h3>	
			<InfiniteScroll
            loadMore={this.loadFunc}
            hasMore={this.state.hasMore}
            loader={<div className="loader">Loading ...</div>}
            >
                                   
                    {items}           
                 
            </InfiniteScroll>
		
		</div>
		
		<Footer />
                
            </div>
        )
	}
	getShop(){
		var url='http://localhost:8001/api/shop?page='+this.state.page;
		axios.get(url)
		.then((response)=> {
		//   console.log(response.data.result);
		this.setState({        
			list:this.state.list.concat(response.data.result),
			page:++this.state.page
		})
		if(response.data.result.length<10){
			this.setState({                    
				hasMore:false
			})
		}        
	}).catch(function(err){
		console.log(err);        
	})
	}
	loadFunc(){
        this.getShop();
    }
	componentDidMount(){
		this.getShop();
		var add="http://api.map.baidu.com/location/ip?ak=WdGcPRgkkttxFdelszkdojjG8QB4m2ZG";
		axios.get(add,{withCredentials:true})
		.then((response)=> {
		  console.log(response.content);
		this.setState({        
			address:response.content.address
		})

	}).catch(function(err){
		console.log(err);        
	})
	}
	goSearch(){
		this.props.history.push('/search');
	}
	
}

export default Index;
