import React from 'react';
import '../css/Footer.css';
import '../css/Reset.css';
import Myeleno from './Myeleno.js';
import Myeleok from './Myeleok.js';
import Footer from './Footer.js';
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom';

class My extends React.Component{


    constructor(props){
        super(props);

        this.state={
 
            
        }
    }

    render(){

        return(
        	<Router>
            <div id="my">
              
              <Route exact path="/My" component={Myeleno}/>
		      <Route path="/Myeleok" component={Myeleok}/>
              <Route path="/Myeleno" component={Myeleno}/>
              
              <Footer />
            </div>
            </Router>
        )
    }
}

export default My;
