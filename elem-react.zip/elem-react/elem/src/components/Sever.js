import React from 'react';
import '../css/Reset.css';
import '../css/serve.css';
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom';

class Sever extends React.Component{


    constructor(props){
        super(props);

        this.state={
 
            
        }
    }

    render(){

        return(
      
            <div id="sever">
            <div id="header5">
			<div className="h-l">
				<a href="#">X</a>
					<a href="#">服务中心</a>
				
			</div>
		</div>
		<div id="main">
				<div className="usera">
					<ul>
						<li>
							<a href="#">
								<i className="iconfont">&#xe62e;</i>
								 <span>在线客服</span>
							</a>
						</li>
						<li>
							<a href="#">
								<i className="iconfont">&#xe619;</i>
								 <span>客服热线</span>
							</a>
						</li>
					</ul>
				</div>
				<div className="content">
					<h3> 热门问题</h3>
					<ul>
						<li>
							<a href="#">
								<span>准时安全达</span>
								<i>></i>
							</a>
						</li>
						<li>
							<a href="#">
								<span>准时安全达</span>
								<i>></i>
							</a>
						</li>
						<li>
							<a href="#">
								<span>准时安全达</span>
								<i>></i>
							</a>
						</li>
						<li>
							<a href="#">
								<span>准时安全达</span>
								<i>></i>
							</a>
						</li>
						<li>
							<a href="#">
								<span>准时安全达</span>
								<i>></i>
							</a>
						</li>
						<li>
							<a href="#">
								<span>准时安全达</span>
								<i>></i>
							</a>
						</li>
						<li>
							<a href="#">
								<span>准时安全达</span>
								<i>></i>
							</a>
						</li>
						<li>
							<a href="#">
								<span>准时安全达</span>
								<i>></i>
							</a>
						</li>
						<li>
							<a href="#">
								<span>准时安全达</span>
								<i>></i>
							</a>
						</li>
					</ul>
					
				</div>
			</div>
              
            </div>
        )
    }
}

export default Sever;
