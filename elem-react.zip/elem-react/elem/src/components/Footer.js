import React from 'react';

import '../css/Reset.css';
import '../css/Footer.css';
import {
    BrowserRouter as Router,
    Route,
    Link
  } from 'react-router-dom';
class Footer extends React.Component{
    
    constructor(props){
        super(props);

        this.state={

            msg:'底部'
        }
    }

    render() {
        return (
           
            <div>
              
                 
          <ul className="botton">
          <li className="take">
                    <Link to="/index">
                        <i className="iconfont">&#xe6fe;</i>
                        <span>外卖</span>
                        </Link>
                    </li>
                    
                    
                    <li className="faind">
                    <Link to="/Faind">
                        <i className="iconfont">&#xe602;</i>
                        <span>发现</span>
                        </Link>
                    </li>
                    
                    
                    <li className="indent">
                    <Link to="/Indent">
                        <i className="iconfont">&#xe66c;</i>
                        <span>订单</span>
                        </Link>
                    </li>
                    
                    
                    <li className="my">
                    <Link to="/My">
                        <i className="iconfont">&#xe60a;</i>
                        <span>我的</span>
                        </Link>
                    </li>
                    
            </ul>
                      
            </div>
           
        );
    }
}
export default Footer;