import React from 'react';
import '../css/MyEle01.css';
import Footer from './Footer.js';
import simbol3 from '../img/simbol3.png';
import pic4 from '../img/face.png';
import pic5 from '../img/address.png';
import pic6 from '../img/simbol1.png';
import pic7 from '../img/heart.png';
import pic8 from '../img/cool.png';
import pic9 from '../img/ele.png';
import pic10 from '../img/online.png';
import pic11 from '../img/phone.png';
import pic12 from '../img/heart.png';
import pic13 from '../img/cool.png';
import pic14 from '../img/onsale.png';
import pic15 from '../img/money.png';

import {
	BrowserRouter as Router,
	Route,
	Link,
	withRouter
  } from 'react-router-dom';

class Myeleno extends React.Component{


    constructor(props){
        super(props);

        this.state={
			username:'立即注册',
			tel:'登录后可享受更多特权'
		}
		this.loginOut=this.loginOut.bind(this);
		this.goLogin01=this.goLogin01.bind(this);
    }

    render(){

        return(
            <div>
                 <header className="header">
			<img src={simbol3}/>
			<h2>我的</h2>
		</header>
		
		<section className="userinfo">
			<div className="u_left">
				<i><img src={pic4}/></i>
				<div onClick={this.goLogin01}>
					<h4>{this.state.username}</h4>
					<p>{this.state.tel}</p>
				</div>
			</div>
			<div className="u_right">
				<img src={pic6}/>
			</div>
		</section>
		
		
		<section className="list">
			<div>
					<img src={pic14} />
					<span>红包</span>
			</div>
			
			<div>
					<img src={pic15} />	
					<span>优惠</span>
			</div>
			
			<div>
					<img src={pic8} />	
					<span>积分</span>
			</div>
		</section>
		
		<section className="main">
			
			<div className="block">
				<div>
					<img src={pic5}/>
					<span>我的地址 <i className="arror">&gt;</i></span>				
				</div>
				<div>
					<img src={pic7}/>
					<span>我的收藏 <i className="arror">&gt;</i></span>				
				</div>
				
			</div>
			<div className="block">
				<div>
					<img src={pic8}/>
					<span>金币商城<i className="arror">&gt;</i></span>
				</div>
				<div>
					<img src={pic9}/>
					<span>分享拿五元现金<i className="arror">&gt;</i></span>
				</div>
				
				
			</div>
			<div className="block">
				<div>
					<img src={pic10}/>
					<span>我的客服<i className="arror">&gt;</i></span>
				</div>
				<div>
					<img src={pic11}/>
					<span>下载饿了么APP<i className="arror">&gt;</i></span>
				</div>
			</div>
			
			<div className="block">
				<div>
					<img src={pic12}/>
					<span>服务中心<i className="arror">&gt;</i></span>
				</div>
				<div>
					<img src={pic13}/>
					<span>下载饿了么APP<i className="arror">&gt;</i></span>
				</div>
				<div onClick={this.loginOut}>
				<img src={pic13}/>
				<span>退出登录<i className="arror">&gt;</i></span>
			</div>
			</div>
			
			
		</section>
		
		<Footer />
            </div>
        )
	}
	loginOut(){
		var storage = {
			setItem: function(key, value) {
				localStorage.setItem(key, JSON.stringify(value));
			},
			getItem: function(key) {
				return JSON.parse(localStorage.getItem(key));
			},
			removeItem: function(key) {
				localStorage.removeItem(key);
			},
			clear: function() {
				localStorage.clear();
			}
		}
		if(window.confirm('确定退出登录？')){
			storage.removeItem('username');
			storage.removeItem('tel');
			this.setState({
				username:'立即登录',
				tel:'登录后可享受更多特权'
			})
		}
		
	}
	goLogin01(){
		this.props.history.push('/login01');
	}
	componentDidMount(){
		var storage = {
			setItem: function(key, value) {
				localStorage.setItem(key, JSON.stringify(value));
			},
			getItem: function(key) {
				return JSON.parse(localStorage.getItem(key));
			},
			removeItem: function(key) {
				localStorage.removeItem(key);
			},
			clear: function() {
				localStorage.clear();
			}
		}
		if(storage.getItem('username')&&storage.getItem('tel')){
			this.setState({
				username:storage.getItem('username'),
				tel:storage.getItem('tel')
			})
		}
	}
}






export default Myeleno;