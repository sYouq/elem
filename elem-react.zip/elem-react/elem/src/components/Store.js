import React from 'react';
import '../css/Reset.css';
import '../css/store.css';
import {
  BrowserRouter as Router,
  Route,
  Link
} from 'react-router-dom';

class Store extends React.Component{


    constructor(props){
        super(props);

        this.state={
 
            
        }
    }

    render(){

        return(
            <div id="store">
            <header>
            <div className="arrow">
                <i className="iconfont">&#xe609;</i>
            </div>
            <div className="tit">
                <span>我的收藏</span>
            </div>
        </header>
        <div className="box">
            <div></div>
            <div className="cover">
                <span>展开超出配送范围的商家</span>
                <i className="iconfont">&#xe604;</i>
            </div>
        </div>
            </div>
        )
    }
}

export default Store;
