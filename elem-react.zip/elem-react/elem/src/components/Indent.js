import React from 'react';
import '../css/Indent.css';
 import pic3 from '../img/adsfa.png';
 import Footer from './Footer.js';
 import {
    BrowserRouter as Router,
    Route,
    Link,
    withRouter
  } from 'react-router-dom';
class Indent extends React.Component{

    constructor(props){
        super(props);

        this.state={
            msg:"登录后查看外卖订单",
            btn:"立即登录"
        }
        this.goLogin=this.goLogin.bind(this);
    }

    render(){

        return(
            <div id="indent">
                <div className="head">
			<a>订单</a>
			<a>早餐</a>
		</div>
		<div className="nav">
			<img src={pic3}/>
			<span>{this.state.msg}</span>
			<button onClick={this.goLogin}>{this.state.btn}</button>
		</div>
        <Footer />
            </div>
        )
    }
    goLogin(){
        
        var storage = {
            setItem: function(key, value) {
                localStorage.setItem(key, JSON.stringify(value));
            },
            getItem: function(key) {
                return JSON.parse(localStorage.getItem(key));
            },
            removeItem: function(key) {
                localStorage.removeItem(key);
            },
            clear: function() {
                localStorage.clear();
            }
        }
        if(storage.getItem('username')&&storage.getItem('tel')){
            this.props.history.push('/order');
        }else{
            this.props.history.push('/login');
        }
                
    }
    
    componentDidMount(){
        var storage = {
            setItem: function(key, value) {
                localStorage.setItem(key, JSON.stringify(value));
            },
            getItem: function(key) {
                return JSON.parse(localStorage.getItem(key));
            },
            removeItem: function(key) {
                localStorage.removeItem(key);
            },
            clear: function() {
                localStorage.clear();
            }
        }
		if(storage.getItem('username')&&storage.getItem('tel')){
            this.setState({
                msg:"欢迎"+storage.getItem('username')+"来到饿了么",
                btn:"查看订单"
            })
        }
	}
}

export default Indent;
