import React from 'react';
import '../css/Reset.css';
import '../css/detials.css';
import bt from '../img/bt.jpg'
import {
  BrowserRouter as Router,
  Route,
  Link,
  withRouter
} from 'react-router-dom';
import axios from 'axios';

class Detials extends React.Component{


    constructor(props){
        super(props);

        this.state={
				name:"团购详情",
				pic:"http://localhost:8001/public/admin/upload/CH4n9QYF70gT8lj6huM61Z3B.png",
				address:"不支持随时退款",
				tel:''
		}
		this.goBack=this.goBack.bind(this);
		this.send=this.send.bind(this);
    }

    render(){

        return(
        	
            <div>
            <div id="header3">
			<div className="back iconfont" onClick={this.goBack}>&#xe648;</div>
				<h2>{this.state.name}</h2>
				<div className="h-r">
					<div className="h-e">
						<a href="#">
						<i className="iconfont">&#xe68b;</i>
						 <span>收藏</span>
						 </a>
					</div>
					<div className="h-t">
						<a href="#">
						<i className="iconfont">&#xe641;</i>
						<span>导航</span>
						</a>
					</div>
				</div>
			
		</div>
		<div id="banner">
			<a href="#">
				<img src={this.state.pic}/>
			</a>
			
		</div>
		<div id="b-x">
			<div className="dsd">
				<div className="dsd-q">
				<strong>183<span>元</span><i>门市价：198元</i></strong>
				</div>
				<div className="dsd-w">
					<a href="#" onClick={this.send}>
						立即抢购
					</a>
				</div>
			</div>
		</div>
		<div id="main">
			<div className="main-q">
				<ul>
					<li>
						<span>{this.state.address}</span>
					</li>
					<li>
						<span>支持过期退款</span>
					</li>
					<li>已售6280</li>
				</ul>
				
			</div>
		</div>
		<div className="tiao"></div>
		 <div className="listq">
		 	<ul>
		 		<li>
		 			<a href="#">
		 			<img src={bt} />
		 				<h5>家家知蛋糕连锁店</h5>
		 				<p>[20店通用]20元代金券1张，可叠加</p>
		 				<span>
		 					<i>15.5元</i>门市价：12元
		 				</span>
		 				<b>已售66685</b>
		 			</a>
		 		</li>
		 		<li>
		 			<a href="#">
		 				<img src={bt} />
		 				<h5>家家知蛋糕连锁店</h5>
		 				<p>[20店通用]20元代金券1张，可叠加</p>
		 				<span>
		 					<i>15.5元</i>门市价：12元
		 				</span>
		 				<b>已售66685</b>
		 			</a>
		 		</li>
		 		<li>
		 			<a href="#">
		 				<img src={bt} />
		 				<h5>家家知蛋糕连锁店</h5>
		 				<p>[20店通用]20元代金券1张，可叠加</p>
		 				<span>
		 					<i>15.5元</i>门市价：12元
		 				</span>
		 				<b>已售66685</b>
		 			</a>
		 		</li>
		 		<li>
		 			<a href="#">
		 				<img src={bt} />
		 				<h5>家家知蛋糕连锁店</h5>
		 				<p>[20店通用]20元代金券1张，可叠加</p>
		 				<span>
		 					<i>15.5元</i>门市价：12元
		 				</span>
		 				<b>已售66685</b>
		 			</a>
		 		</li>
		 		<li>
		 			<a href="#">
		 				<img src={bt} />
		 				<h5>家家知蛋糕连锁店</h5>
		 				<p>[20店通用]20元代金券1张，可叠加</p>
		 				<span>
		 					<i>15.5元</i>门市价：12元
		 				</span>
		 				<b>已售66685</b>
		 			</a>
		 		</li>
		 	</ul>
		 </div>
		 
              
            </div>
          
        )
	}
	goBack(){
		this.props.history.push('/');
	}
	send(){
		var storage = {
			setItem: function(key, value) {
				localStorage.setItem(key, JSON.stringify(value));
			},
			getItem: function(key) {
				return JSON.parse(localStorage.getItem(key));
			},
			removeItem: function(key) {
				localStorage.removeItem(key);
			},
			clear: function() {
				localStorage.clear();
			}
		}
		if(storage.getItem('username')&&storage.getItem('tel')){
			axios.post('http://localhost:8001/api/order/', {
				"shop_id":this.props.match.params.aid,
				"shop_name":this.state.name,
				"shop_tel":this.state.tel,
				"username":storage.getItem('username'),
				"user_tel":storage.getItem('tel'),
				"order_id":this.props.match.params.aid,
				"uid":storage.getItem('tel')
			  })
			  .then((response)=> {
				  alert(response.data);
				  this.props.history.push('/order');
			  })
			  .catch((error)=> {
				console.log(error);
			  });
		}else{
			if(window.confirm("未登录，去登录")){
				this.props.history.push('/login');
			}
		}
	}
	componentDidMount(){
		console.log(this.props.match.params.aid);
		axios.post('http://localhost:8001/api/shop/id', {
			"id":this.props.match.params.aid
		  })
		  .then((response)=> {
			  console.log(response.data.result);
			  if(response.data.result){
				this.setState({
					name:response.data.result.name,
					pic:'http://localhost:8001/' + response.data.result.pic,
					address:response.data.result.address,
					tel:response.data.result.tel
				})
			  }
		  })
		  .catch((error)=> {
			console.log(error);
		  });
	}
}

export default Detials;
