import React from 'react';

import '../css/order.css';
import '../css/Reset.css';
import {
  BrowserRouter as Router,
  Route,
  Link,
  withRouter
} from 'react-router-dom';
import axios from 'axios';
class Order extends React.Component{

    constructor(props){
        super(props);

        this.state={
		  page:1,
		  list:[]
		  
		}
		this.goBack=this.goBack.bind(this);
    }

    render(){

        return(
            <div>
            <div id="header1">
			<div className="h-top">
                <a href="#" className="iconfont" onClick={this.goBack}>&#xe648;</a>
				<span>订单配送至</span>
			</div>
			<div className="add-site">
				<a href="#">
					<small>+</small><span>添加收货地址</span>
				</a>
			</div>
		</div>
		
		<div id="zs">
			<div className="zs-top">
				<a href="#">
					<p>
						<span>尽快送达[预计12:02]</span>
						<small>蜂鸟专送</small>
					</p>
				</a>
				<a href="#" className="iconfont">&#xe608;</a>
			</div>
			<div className="zs-bottom">在线支付</div>
		</div>
		
		<div id="eat">
			{
				this.state.list.map(function(item,key){
					return <div key={key}>
					<h3><span>{item.shop_name}</span></h3>
					<p>
						<span>辣子鸡</span>
						<span>
							<small>*1</small>
							<small>￥35.6</small>
						</span>
					</p>
					<div className="canhe">
						<p>
							<span>餐盒</span>
							<span>
								<small>￥1</small>
							</span>
						</p>
						<p>
							<span>配送费</span>
							<span>
								<small>￥1</small>
							</span>
						</p>
					</div>
					</div>
				})
			}
			
			<div className="hongbao">
				<p>
					<span>红包</span>
					<span>
						选择地址后使用红包
					</span>
				</p>
				<p>
					<span>配送费</span>
					<span>
						<a href="#">无可用商家代金券<small>></small></a>
					</span>
				</p>
			</div>
		</div>
		
		<div id="footer">
			<div className="jiesuan">
				<span>￥{parseInt(this.state.list.length*37.6*100)/100}</span>
				<a href="#">去支付</a>
			</div>
		</div>
            </div>
        )
	}
	goBack(){
		this.props.history.push('/indent');
	}
	componentDidMount(){
		var storage = {
			setItem: function(key, value) {
				localStorage.setItem(key, JSON.stringify(value));
			},
			getItem: function(key) {
				return JSON.parse(localStorage.getItem(key));
			},
			removeItem: function(key) {
				localStorage.removeItem(key);
			},
			clear: function() {
				localStorage.clear();
			}
		}
		if(storage.getItem('username')&&storage.getItem('tel')){
			var url='http://localhost:8001/api/order/uid?page='+this.state.page
			axios.post(url, {
				"uid":storage.getItem('tel')
			  })
			  .then((response)=> {
				  console.log(response.data.result);
				  this.setState({
					list:this.state.list.concat(response.data.result),
					page:++this.state.page
				  })
			  })
			  .catch((error)=> {
				console.log(error);
			  });
		}else{
			if(window.confirm('未登录，去登录')){
				this.props.history.push('/login');
			}
		}
	}
}

export default Order;
