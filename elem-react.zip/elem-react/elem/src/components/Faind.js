import React from 'react';
 import pic1 from '../img/199d358d7d5757ab2f6184b153cc4jpeg.jpeg';
 import pic2 from '../img/45b2ec2855ed55d90c45bf9b07abbpng.png';
import '../css/Faind.css';
import '../css/Reset.css';
import Footer from './Footer.js';


 
class Faind extends React.Component{


    constructor(props){
        super(props);

        this.state={

           
        }
    }

    render(){

        return(
         <div id="faind">
		     <div className="faind_head">
			 <a className="iconfont">&#xe648;</a>
			 <span>发现</span>
		     </div>
		  <div className="naa">
			<div className="nav_left">
				<div className="lefttop">
					<a>
						<span>积分商城</span>
						<i>0元好物在这里</i>
						<img src={pic1}/>
					</a>
				</div>
				<div className="leftbot">
					<a> 
						<div className="aleft">
						<span>免费流量</span>
						<i>最高每月500M</i>
					    </div>
						
						<img src={pic1}/>
					</a>
				</div>
			</div>
			<div className="nav_right">
				<div className="righttop">
					<a> 
						<div className="aleft">
						<span>美味爆料</span>
						<i>承包你的小爆料</i>
					    </div>
						
						<img src={pic1}/>
					</a>
				</div>
				<div className="rightbot">
					<div className="top">
						<a> 
						<div className="aleft">
						<span className="sp2">推荐有奖</span>
						<i>承包你的小爆料</i>
					    </div>
						
						<img src={pic1}/>
					    </a>
					</div>
					<div className="bot">
						<a> 
						<div className="aleft">
						<span className="sp3">有红包快抢</span>
						<i>五元现金拿不停</i>
					    </div>
						
						<img src={pic1}/>
					</a>
					</div>
				</div>
			</div>
		</div>
		               
		<div className="img">
			<img src={pic2}/>
		</div>
		
		<div className="content">
			<div className="top">
				<i className="iconfont">&#xe6a0;</i>
				<span><b>天天特价</b></span>
			</div>
			<span className="sp1">你的口味，我都懂得</span>
			<div className="cen">
				<a className="cen_a">
					<img src={pic1}/>
					<p>李长猛全场半价一块钱</p>
					<span><i>￥</i>11</span>
				</a>
				<a className="cen_c">
					<img src={pic1}/>
					<p>李长猛全场半价一块钱</p>
					<span><i>￥</i>11</span>
				</a>
				<a className="cen_c">
					<img src={pic1}/>
					<p>李长猛全场半价一块钱</p>
					<span><i>￥</i>11</span>
				</a>
			</div>
			<div className="bot">查看更多></div>
		</div>
		
		<div className="content">
			<div className="top">
				<i className="iconfont">&#xe6a0;</i>
				<span><b>天天特价</b></span>
			</div>
			<span className="sp1">你的口味，我都懂得</span>
			<div className="cen">
				<a className="cen_a">
					<img src={pic1}/>
					<p>李长猛全场半价一块钱</p>
					<span><i>￥</i>11</span>
				</a>
				<a className="cen_c">
					<img src={pic1}/>
					<p>李长猛全场半价一块钱</p>
					<span><i>￥</i>11</span>
				</a>
				<a className="cen_c">
					<img src={pic1}/>
					<p>李长猛全场半价一块钱</p>
					<span><i>￥</i>11</span>
				</a>
			</div>
			<div className="bot">查看更多></div>
		</div>
	    
                <Footer/>
            </div>
        );
    }
}

export default Faind;
