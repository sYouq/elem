import React from 'react';

import '../css/Reset.css';
import '../css/login02.css';
import axios from 'axios';
import {
  BrowserRouter as Router,
  Route,
  Link,
  withRouter
} from 'react-router-dom';

class Login02 extends React.Component{
    constructor(props){
        super(props);
        this.state={
			password:''
		}
		this.passChange=this.passChange.bind(this);
		this.doLogin=this.doLogin.bind(this);
		this.goBack=this.goBack.bind(this);
    }
	
    render(){

        return(
            <div id="login02">
              <div id="header">
			<div className="h-l">
				<i className="iconfont" onClick={this.goBack}>&#xe609;</i>
					<a href="#">设置登陆密码</a>
				
			</div>
		</div>
		<div id="main">
				<div className="content">
					<h3>设置登录密码后，您可以使用手机号码+密码登陆，请牢记</h3>
				</div>
				<div className="iph">
				<span>密码</span>
				<input type="password" value={this.state.password} onChange={this.passChange} />
		</div>
		<div className="content-q">
			<h3>密码长度6-20字符</h3>
		</div>
		<div className="cl">
				<a href="#" onClick={this.doLogin}>
					登陆
				</a>	
			</div>
				
			</div>
              
            </div>
        )
	}
	passChange(event){
		this.setState({password: event.target.value});
	}
	doLogin(){
		var storage = {
			setItem: function(key, value) {
				localStorage.setItem(key, JSON.stringify(value));
			},
			getItem: function(key) {
				return JSON.parse(localStorage.getItem(key));
			},
			removeItem: function(key) {
				localStorage.removeItem(key);
			},
			clear: function() {
				localStorage.clear();
			}
		}
		axios.post('http://localhost:8001/api/user/register', {
			"tel":storage.getItem('tel'),
			"username":storage.getItem('username'),
			"password":this.state.password

		  })
		  .then((response)=> {
			//   console.log(response);
			alert(response.data.msg);
			if(response.data.result==true){
				this.props.history.push('/login');
			}
		  })
		  .catch((error)=> {
			console.log(error);
		  });
	}
	goBack(){
		this.props.history.push('/login01');
	}
}

export default Login02;
