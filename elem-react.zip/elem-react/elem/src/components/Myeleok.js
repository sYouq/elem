import React from 'react';
import '../css/MyEle02.css';
import Footer from './Footer.js';
import simbol3 from '../img/simbol3.png';
import pic4 from '../img/201710090639311597734.jpg';
import pic5 from '../img/address.png';
import pic6 from '../img/simbol1.png';
import pic7 from '../img/heart.png';
import pic8 from '../img/cool.png';
import pic9 from '../img/ele.png';
import pic10 from '../img/online.png';
import pic11 from '../img/phone.png';
import pic12 from '../img/heart.png';
import pic13 from '../img/cool.png';

class Myeleok extends React.Component{


    constructor(props){
        super(props);

        this.state={
                msg:"da"
        }
    }

    render(){

        return(
            <div>
                <header className="header">
			<img src={simbol3}/>
			<h2>我的</h2>
		</header>
		
		<section className="userinfo">
			<div className="u_left">
				<i><img src={pic4}/></i>
				<div>
					<h4>lorretta</h4>
					<p>186****8866</p>
				</div>
			</div>
			<div className="u_right">
				<img src={pic6}/>
			</div>
		</section>
		
		
		<section className="list">
			<div>
					<p><b>10</b> 个</p>
					<span>红包</span>
			</div>
			
			<div>
					<p><b>0</b> 个</p>
					<span>优惠</span>
			</div>
			
			<div>
					<p><b>100</b> 分</p>
					<span>积分</span>
			</div>
		</section>
		
		<section className="main">
			
			<div className="block">
				<div>
					<img src={pic5}/>
					<span>我的地址 <i className="arror">&gt;</i></span>				
				</div>
				<div>
					
					<img src={pic7}/>
					<span>我的收藏 <i className="arror">&gt;</i></span>				
				</div>
			</div>
			<div className="block">
				<div>
				   <img src={pic8}/>
					
					<span>金币商城<i className="arror">&gt;</i></span>
				</div>
				<div>
				    <img src={pic9}/>
					
					<span>分享拿五元现金<i className="arror">&gt;</i></span>
				</div>
				
				
			</div>
			<div className="block">
				<div>
				<img src={pic10}/>
					
					<span>我的客服<i className="arror">&gt;</i></span>
				</div>
				<div>
				<img src={pic11}/>
					
					<span>下载饿了么APP<i className="arror">&gt;</i></span>
				</div>
			</div>
			
			<div className="block">
				<div>
				    <img src={pic12}/>
					
					<span>服务中心<i className="arror">&gt;</i></span>
				</div>
				<div>
				    <img src={pic13}/>
					
					<span>下载饿了么APP<i className="arror">&gt;</i></span>
				</div>
			</div>
			
			
		</section>
		
		
		
		<div className="botton">
			
				<a className="take">
					<div className="iconfont">&#xe6fe;</div>
					<span>外卖</span>
				</a>
				<a className="faind">
					<div className="iconfont">&#xe602;</div>
					<span>发现</span>
				</a>
				<a className="indent">
					<div className="iconfont">&#xe66c;</div>
					<span>订单</span>
				</a>
				<a className="my">
					<div className="iconfont">&#xe60a;</div>
					<span>我的</span>
				</a>
			
		</div>
               <Footer />
            </div>
        )
    }
}

export default Myeleok;