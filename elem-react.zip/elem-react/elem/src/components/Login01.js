import React from 'react';

import '../css/Reset.css';
import '../css/login01.css';
import axios from 'axios';
import {
  BrowserRouter as Router,
  Route,
  Link,
  withRouter
} from 'react-router-dom';

class Login01 extends React.Component{
    constructor(props){
        super(props);
        this.state={
			num:60,
			flag:true,
			tel:'',
			yzm:''
		
		}
		this.doTimer=this.doTimer.bind(this);
		this.sendCode=this.sendCode.bind(this);
		this.getState=this.getState.bind(this);
		this.telChange = this.telChange.bind(this);
		this.yzmChange = this.yzmChange.bind(this);
		this.doLogin = this.doLogin.bind(this);
		this.goBack=this.goBack.bind(this);
    }

    render(){

        return(
            <div id="login01">
              <div id="header">
			<div className="h-l">
				<i className="iconfont" onClick={this.goBack}>&#xe609;</i>
					<a href="#">登陆</a>
				
			</div>
			<div className="h-r">
				<a href="#">密码登录</a>
			</div>
		</div>
		<div id="mian">
			<div className="iph">
				<span>手机号</span>
				<input type="text" value={this.state.tel} onChange={this.telChange}/>
				<p onClick={this.getState}>{this.state.flag? <button>{this.state.num}</button>:<button onClick={this.sendCode}>重新发送</button>}</p>
				
			</div>
			<div className="ipq">
				<span>验证码</span>
				<input type="text" value={this.state.yzm} onChange={this.yzmChange} />
			</div>
			<div className="talk">
				<p>温馨提示：未注册饿了么账号的手机号，登录时将自动注册，且代表您已同意<span>用户服务协议</span></p>
			</div>
			<div className="cl">
				<a href="#" onClick={this.doLogin}>
					登陆
				</a>	
			</div>
			<div className="blank"></div>
			<div className="xixi">
			  第三方登陆
			</div>
		
		</div>
              
            </div>
        )
	}
	yzmChange(event){
		this.setState({yzm: event.target.value});
	}
	telChange(event) {
		this.setState({tel: event.target.value});
	}
	doTimer(){
	        var timer=setInterval(()=>{
	                this.setState({
	                    num:--this.state.num
	                })
	                if(this.state.num==0){
	                    //停止倒计时
	                    clearInterval(timer);
	                    this.setState({  /*改变状态*/
	                        flag:false
	                    })
	                }
	        },1000)
	
	    }
		
		sendCode(){
       
	        this.setState({  /*改变状态*/
	            flag:true,
	            num:60
	        })
			this.doTimer();   /*重新发送请求 生成随机验证码并且倒计时*/   
			 
			   
	    }
		
		getState(){
			 this.setState({  /*改变状态*/
	            num:60
	        })
			this.doTimer();
			axios.post('http://localhost:8001/api/user/tel', {
				"tel":this.state.tel
			  })
			  .then((response)=> {
				//   console.log(response);
				alert(response.data.result);
			  })
			  .catch((error)=> {
				console.log(error);
			  });
		}
		doLogin(){
			var storage = {
				setItem: function(key, value) {
					localStorage.setItem(key, JSON.stringify(value));
				},
				getItem: function(key) {
					return JSON.parse(localStorage.getItem(key));
				},
				removeItem: function(key) {
					localStorage.removeItem(key);
				},
				clear: function() {
					localStorage.clear();
				}
			}
			axios.post('http://localhost:8001/api/user/yz', {
				"tel":this.state.tel,
				"yzm":this.state.yzm
			  })
			  .then((response)=> {
				alert(response.data.msg);
				if(response.data.result==true){
					storage.setItem("tel",this.state.tel);
					storage.setItem("username",this.state.tel);
					this.props.history.push('/login02');
				}
			  })
			  .catch((error)=> {
				console.log(error);
			  });
		}
		componentDidMount(){
	        this.setState({  /*改变状态*/
	            num:'点击获取验证码'
	        })
		}
		goBack(){
			this.props.history.push('/my');
		}
}

export default Login01;
